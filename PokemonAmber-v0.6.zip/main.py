from functions.libs import *

generate('fearful_forest_entrance')