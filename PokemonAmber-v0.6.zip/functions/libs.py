from json import *
from random import *
from time import *
import os
import winsound
from pprint import pprint
from functions.lyoflib import *
import functions.trainer as account
from functions.fight import *